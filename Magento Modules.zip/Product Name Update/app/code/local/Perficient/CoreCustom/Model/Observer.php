<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 2/29/2016
 * Time: 2:45 PM
 */
class Perficient_CoreCustom_Model_Observer
{
    /**
     * @param Varien_Event_Observer $observer
     */
    public function  changeProductName(Varien_Event_Observer $observer)
    {
         $configValue = Mage::getStoreConfig('corecustom_section/corecustom_groups/corecustom_field_val');
        if ($configValue) {
            $product = $observer->getProduct();
            //$product->setName(strtoupper($product->getName()));
            $product->setName(strtoupper($product->getName()).'-UC-');
        }
    }
}