<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 11-04-2016
 * Time: 18:39
 */

class Perficient_CoreCustom_Helper_Data extends Mage_Core_Helper_Abstract
{

}