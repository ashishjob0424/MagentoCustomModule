<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 3/16/2016
 * Time: 12:35 PM
 */
class Perficient_Faq_Model_Resource_Faq_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
    protected function _construct()
    {
        parent::_construct();
        $this->_init('perficient_faq/faq');
    }
}