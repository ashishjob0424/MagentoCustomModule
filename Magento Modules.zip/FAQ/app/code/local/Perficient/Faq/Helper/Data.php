<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 3/18/2016
 * Time: 3:39 PM
 */
class Perficient_Faq_Helper_Data extends Mage_Core_Helper_Abstract
{

}