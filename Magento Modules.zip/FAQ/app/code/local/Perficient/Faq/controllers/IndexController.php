<?php
/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 3/16/2016
 * Time: 10:59 AM
 */

/**
 * Class Perficient_Faq_IndexController
 */
class Perficient_Faq_IndexController extends Mage_Core_Controller_Front_Action
{
    /**
     * index action to load default layout
     */
    public function indexAction()
    {
        $this->loadLayout()->renderLayout();
    }

    /**
     * Saves data in the database after form submit
     */
    public function saveAction()
    {
        $customerName = $this->getRequest()->getPost('name');
        $question = $this->getRequest()->getPost('question');
        $store_id = $this->getRequest()->getPost('store_id');

        if (isset($customerName)&&($customerName!='') && isset($question)&&($question!='')) {
            try {
                $date = Mage::getModel('core/date')->timestamp(time());
                $faq = Mage::getModel('perficient_faq/faq');
                $faq->setData('question', $question);
                $faq->setData('create_date', $date);
                $faq->setData('update_date', $date);
                $faq->setData('customer_name', $customerName);
                $faq->setData('store_id', $store_id);
                $faq->save();
                $messages = "Your Question successfully Submitted.";
                Mage::getSingleton('core/session')->addSuccess($messages);
            }
            catch (Exception $e){
                $messages = $e->getMessage();
                Mage::getSingleton('core/session')->addError($messages);
            }
        }
        $this->_redirectReferer();
    }
}