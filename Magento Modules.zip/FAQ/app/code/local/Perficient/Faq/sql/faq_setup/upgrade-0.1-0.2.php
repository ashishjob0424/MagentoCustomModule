<?php
/**
 * Alter table
 */
    $installer = $this;
    $installer->startSetup();
    $installer->run(
        "ALTER TABLE `{$this->getTable('perficient_faq/faq')}` ADD COLUMN `status` INT(2) DEFAULT 1 NOT NULL"
    );
    $installer->endSetup();