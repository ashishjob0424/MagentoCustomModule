<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 3/16/2016
 * Time: 3:04 PM
 */

/**
 * Create table into the database
 */
$installer = $this;
$installer->startSetup();
$installer->run(
    "CREATE TABLE `{$this->getTable('perficient_faq/faq')}` (
    `faq_id` int(10) NOT NULL AUTO_INCREMENT,
    `question` text,
    `answer` text,
    `create_date` datetime DEFAULT NULL,
    `update_date` datetime DEFAULT NULL,
    `sort_no` int(10) DEFAULT NULL,
    `store_id` VARCHAR(50) NOT NULL,
    `customer_name` varchar(255) NULL,
    PRIMARY KEY (`faq_id`)
    ) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;"
);
$installer->endSetup();