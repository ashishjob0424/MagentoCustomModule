<?php

/**
 * Class Perficient_Faq_Block_Adminhtml_Faq_Edit_Tab_Form
 */
class Perficient_Faq_Block_Adminhtml_Faq_Edit_Tab_Form extends Mage_Adminhtml_Block_Widget_Form
{
    /**
     * Creating form fields
     * @return Mage_Adminhtml_Block_Widget_Form
     */
    protected function _prepareForm()
    {

        $form = new Varien_Data_Form();
        $this->setForm($form);
        $fieldset = $form->addFieldset(
            "faq_form", array("legend"=>Mage::helper("perficient_faq")->__("Item information")
            )
        );

        $fieldset->addField(
            'status', 'select', array(
            'label'     => Mage::helper('perficient_faq')->__('Status'),
            'name'      => 'status',
            'values'    => array(
                array(
                    'value'     => 1,
                    'label'     => Mage::helper('perficient_faq')->__('Enabled'),
                ),

                array(
                    'value'     => 0,
                    'label'     => Mage::helper('perficient_faq')->__('Disabled'),
                ),
            ),
            )
        );

        $fieldset->addField(
            "customer_name", "text", array(
            "label" => Mage::helper("perficient_faq")->__("Customer Name"),
            "name" => "customer_name",
            'required' => true,
            )
        );

        $fieldset->addField(
            "question", "textarea", array(
            "label" => Mage::helper("perficient_faq")->__("Question"),
            "name" => "question",
            'required' => true,
            )
        );

        $fieldset->addField(
            "answer", "textarea", array(
            "label" => Mage::helper("perficient_faq")->__("Answer"),
            "name" => "answer",
            'required' => true,
            )
        );

        $fieldset->addField(
            "sort_no", "text", array(
            "label" => Mage::helper("perficient_faq")->__("Sort No"),
            "name" => "sort_no",
            'required' => true,
            )
        );

        if (!Mage::app()->isSingleStoreMode()) {
            $fieldset->addField(
                'store_id', 'select', array(
                'name' => 'stores[]',
                'label' => Mage::helper('perficient_faq')->__('Store View'),
                'title' => Mage::helper('perficient_faq')->__('Store View'),
                'required' => true,
                'values' => Mage::getSingleton('adminhtml/system_store')->getStoreValuesForForm(false, true),
                )
            );
        } else {
            $fieldset->addField(
                'store_id', 'hidden', array(
                'name' => 'stores[]',
                'value' => Mage::app()->getStore(true)->getId(),
                )
            );
        }

        if (Mage::getSingleton("adminhtml/session")->getFaqData()) {
            $form->setValues(Mage::getSingleton("adminhtml/session")->getFaqData());
            Mage::getSingleton("adminhtml/session")->getFaqData(null);
        } elseif (Mage::registry("faq_data")) {
            $form->setValues(Mage::registry("faq_data")->getData());
        }
        return parent::_prepareForm();
    }
}
