<?php

/**
 * Class Perficient_Faq_Block_Adminhtml_Faq_Grid
 */
class Perficient_Faq_Block_Adminhtml_Faq_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    /**
     * Perficient_Faq_Block_Adminhtml_Faq_Grid constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId("faqGrid");
        $this->setDefaultSort("faq_id");
        $this->setDefaultDir("DESC");
        $this->setSaveParametersInSession(true);
    }

    /**
     * @return Mage_Adminhtml_Block_Widget_Grid
     */
    protected function _prepareCollection()
    {
        $collection = Mage::getModel("perficient_faq/faq")->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    /**
     * Setting columns for a grid
     * @return $this
     * @throws Exception
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            "faq_id", array(
            "header" => Mage::helper("perficient_faq")->__("ID"),
            "align" =>"right",
            "width" => "50px",
            "type" => "number",
            "index" => "faq_id",
            )
        );

        $this->addColumn(
            "customer_name", array(
            "header" => Mage::helper("perficient_faq")->__("Customer Name"),
            "index" => "customer_name",
            )
        );

        $this->addColumn(
            "question", array(
            "header" => Mage::helper("perficient_faq")->__("Question"),
            "index" => "question",
            )
        );

        $this->addColumn(
            "create_date", array(
            "header" => Mage::helper("perficient_faq")->__("Create Date"),
            "align" =>"left",
            "width" => "250px",
            "type" => "datetime",
            "index" => "create_date",
            )
        );

        $this->addColumn(
            "sort_no", array(
            "header" => Mage::helper("perficient_faq")->__("Sort No"),
            "align" =>"right",
            "width" => "50px",
            "type" => "number",
            "index" => "sort_no",
            )
        );

        if (!Mage::app()->isSingleStoreMode()) {
            $this->addColumn(
                'store_id', array(
                'header'    => Mage::helper('sales')->__('Store'),
                'index'     => 'store_id',
                'type'      => 'store',
                'store_view'=> true,
                'display_deleted' => true,
                )
            );
        }
        $this->addColumn(
            'status', array(
            'header'    => Mage::helper('perficient_faq')->__('Status'),
            'align'     => 'left',
            'width'     => '80px',
            'index'     => 'status',
            'type'      => 'options',
            'options'   => array(
                1 => 'Enabled',
                0 => 'Disabled',
            ),
            )
        );


        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }

    /**
     * setting row url for click
     * @param $row
     * @return string
     */
    public function getRowUrl($row)
    {
        return $this->getUrl("*/*/edit", array("faq_id" => $row->getId()));
    }

    /**
     * For Bulk process
     * @return $this
     */
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('faq_id');
        $this->getMassactionBlock()->setFormFieldName('faq_ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem(
            'remove_faq', array(
            'label'=> Mage::helper('perficient_faq')->__('Remove Faq'),
            'url'  => $this->getUrl('*/adminhtml_faq/massRemove'),
            'confirm' => Mage::helper('perficient_faq')->__('Are you sure?')
            )
        );
        return $this;
    }
}