<?php

/**
 * Class Perficient_Faq_Block_Adminhtml_Faq_Edit_Tabs
 */
class Perficient_Faq_Block_Adminhtml_Faq_Edit_Tabs extends Mage_Adminhtml_Block_Widget_Tabs
{
    /**
     * Perficient_Faq_Block_Adminhtml_Faq_Edit_Tabs constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId("faq_tabs");
        $this->setDestElementId("edit_form");
        $this->setTitle(Mage::helper("perficient_faq")->__("Item Information"));
    }

    /**
     * @return Mage_Core_Block_Abstract
     * @throws Exception
     */
    protected function _beforeToHtml()
    {
        $this->addTab(
            "form_section", array(
            "label" => Mage::helper("perficient_faq")->__("Item Information"),
            "title" => Mage::helper("perficient_faq")->__("Item Information"),
            "content" => $this->getLayout()->createBlock("perficient_faq/adminhtml_faq_edit_tab_form")->toHtml(),
            )
        );
        return parent::_beforeToHtml();
    }

}
