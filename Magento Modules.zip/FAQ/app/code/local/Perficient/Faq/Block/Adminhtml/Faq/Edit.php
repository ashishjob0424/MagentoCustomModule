<?php

/**
 * Class Perficient_Faq_Block_Adminhtml_Faq_Edit
 */
class Perficient_Faq_Block_Adminhtml_Faq_Edit extends Mage_Adminhtml_Block_Widget_Form_Container
{
    /**
     * Save and continue Button
     * Perficient_Faq_Block_Adminhtml_Faq_Edit constructor.
     */
    public function __construct()
    {

        parent::__construct();
        $this->_objectId = "faq_id";
        $this->_blockGroup = "perficient_faq";
        $this->_controller = "adminhtml_faq";

        $this->_updateButton("save", "label", Mage::helper("perficient_faq")->__("Save Item"));
        $this->_addButton(
            "saveandcontinue", array(
            "label"     => Mage::helper("perficient_faq")->__("Save And Continue Edit"),
            "onclick"   => "saveAndContinueEdit()",
            "class"     => "save",
            ), -100
        );



        $this->_formScripts[] = "

							function saveAndContinueEdit(){
								editForm.submit($('edit_form').action+'back/edit/');
							}
						";
    }

    /**
     * sets header of the form
     * @return string
     */
    public function getHeaderText()
    {
        if ( Mage::registry("faq_data") && Mage::registry("faq_data")->getId() ) {

            return Mage::helper("perficient_faq")->__(
                "Edit Item '%s'", $this->htmlEscape(Mage::registry("faq_data")->getId())
            );

        } else {

            return Mage::helper("perficient_faq")->__("Add Item");

        }
    }
}