<?php

/**
 * Class Perficient_Faq_Block_Adminhtml_Faq_Edit_Form
 */
class Perficient_Faq_Block_Adminhtml_Faq_Edit_Form extends Mage_Adminhtml_Block_Widget_Form
{
    /**
     * sets form tag
     * @return Mage_Adminhtml_Block_Widget_Form
     * @throws Exception
     */
    protected function _prepareForm()
    {
        $form = new Varien_Data_Form(
            array(
                "id" => "edit_form",
                "action" => $this->getUrl("*/*/save", array("faq_id" => $this->getRequest()->getParam("faq_id"))),
                "method" => "post",
                "enctype" =>"multipart/form-data",
            )
        );
        $form->setUseContainer(true);
        $this->setForm($form);
        return parent::_prepareForm();
    }
}
