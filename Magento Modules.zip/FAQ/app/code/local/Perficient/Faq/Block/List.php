<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 3/16/2016
 * Time: 5:50 PM
 * This block type is use to list a faq on product details page and faq home page
 */
class Perficient_Faq_Block_List extends Mage_Catalog_Block_Product_Abstract
{
    public function __construct()
    {
        parent::__construct();

        /*
         * This is to get list of all FAQ on faq home page
         * with store id and status condition.
         * sort_no is used to set the position
         */
        $store_id = Mage::app()->getStore()->getStoreId();
        $collection = Mage::getModel('perficient_faq/faq')->getCollection();
        $collection->addFieldToFilter('store_id', array('eq' => $store_id));
        $collection->addFieldToFilter('status', array('eq' => 1));
        $collection->setOrder('sort_no', 'ASC');
        $this->setCollection($collection);
    }

    /**
     * @param null $limit
     * @return object
     * This is to list FAQ list on product details page
     * parameter is use to specify no of records want to list.
     */
    public function getFaqData($limit = NULL)
    {
        $store_id = Mage::app()->getStore()->getStoreId();
        if ($limit > 0 || $limit != NULL) {
            $collection = Mage::getModel('perficient_faq/faq')->getCollection();
            $collection->addFieldToFilter('store_id', array('eq' => $store_id));
            $collection->addFieldToFilter('sort_no', array('gt' => 0));
            $collection->addFieldToFilter('status', array('eq' => 1));
            $collection->setOrder('sort_no', 'ASC')->setPageSize($limit);
            return $collection;
        } else {
            $collection = Mage::getModel('perficient_faq/faq')->getCollection();
            $collection->addFieldToFilter('store_id', array('eq' => $store_id));
            $collection->addFieldToFilter('status', array('eq' => 1));
            $collection->setOrder('sort_no', 'ASC');
        }
        return $collection;
    }

    /*
     * This is to populate the customer name on a form while making a new question.
     * if customer already login
     * @return null|string
     */
    public function getCustomerName()
    {
        if (!Mage::getSingleton('customer/session')->isLoggedIn()) {
            return NULL;
        } else {
            $customer_data=Mage::getSingleton('customer/session')->getCustomer();
            return $customer_data->getFirstname() . ' ' . $customer_data->getLastname();
        }

    }

    /**
     * Provide faq form url
     * @return string
     */
    public function getActionOfForm()
    {

        return $this->getUrl('faq/index/save');
    }

    /**
     * Provide faq home page url
     * @return string
     */
    public function getHomeUrl()
    {
        return $this->getUrl('faq');
    }

    /**
     * set pager limit
     * @return $this
     */
    public function _prepareLayout()
    {
        parent::_prepareLayout();
        $pager = $this->getLayout()->createBlock('page/html_pager', 'faq.pager');
        $pager->setAvailableLimit(array(5=>5,10=>10,20=>20,'all'=>'all'));
        $pager->setCollection($this->getCollection());
        $this->setChild('pager', $pager);
        $this->getCollection()->load();
        return $this;
    }

    /**
     * @return string
     */
    public function getPagerHtml()
    {
        return $this->getChildHtml('pager');
    }
}