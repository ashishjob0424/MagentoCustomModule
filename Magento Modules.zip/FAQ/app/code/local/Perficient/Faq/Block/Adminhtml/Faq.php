<?php

/**
 * Class Perficient_Faq_Block_Adminhtml_Faq
 */
class Perficient_Faq_Block_Adminhtml_Faq extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    /**
     * sets controoler and block group
     * Perficient_Faq_Block_Adminhtml_Faq constructor.
     */
    public function __construct()
    {
        $this->_controller = "adminhtml_faq";
        $this->_blockGroup = "perficient_faq";
        $this->_headerText = Mage::helper("perficient_faq")->__("Faq Manager");
        $this->_addButtonLabel = Mage::helper("perficient_faq")->__("Add New Item");
        parent::__construct();
    }
}