<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 15-04-2016
 * Time: 14:35
 */
class Perficient_Contact_IndexController extends Mage_Core_Controller_Front_Action
{
    /**
     * Default Action
     */
    public function indexAction()
    {
        $this->loadLayout()->renderLayout();
    }

    /**
     * Ajax country based state
     */
    public function ajaxStateAction()
    {
        $post_data=$this->getRequest()->getPost();
        $post_data['countryCode'];
        $regionCollection = Mage::getModel('directory/region_api')->items($post_data['countryCode']);
        if (count($regionCollection) != 0) {
            $data =  "<select class='input-text custom-state-container'
                      title='State' name='contact[state]' id='state' tabIndex='7'>";
            foreach ($regionCollection as $key => $states) {
                $data .= "<option value='".$states['region_id']."'>".$states['name']."</option>";
            }
            $data .= "</select>";
            echo $data;
        } else {
            echo "<input type='text' class='input-text custom-state-container'
                  title='State' name='contact[state]' id='state' tabIndex='7'>";
        }
    }

    /**
     * @return bool
     * Form Submit
     */
    public function saveAction()
    {
        $post_data=$this->getRequest()->getPost();
        if (!empty($post_data)) {
            try {
                $data = $post_data['contact'];
                $country = $data['country'];
                $countryCollection = Mage::getModel('directory/country')->loadByCode($country);
                $data['country'] =  $countryCollection->getName();

                $regionId = $data['state'];
                if (is_numeric($regionId)) {
                    $region = Mage::getModel('directory/region')->load($regionId);
                    $data['state'] = $region->getName();
                }

                $data['created_date'] = Mage::getModel('core/date')->timestamp(time());
                $data['update_date'] = Mage::getModel('core/date')->timestamp(time());
                $data['store_id'] = Mage::app()->getStore()->getStoreId();
                $contactData = Mage::getModel("perficient_contact/contact");
                $contactData->addData($data)->save();
                $contactData->save();

                $emailTemplate  = Mage::getModel('core/email_template')
                    ->loadDefault('contact_section_contact_group_contact_email_template');

                $processedTemplate = $emailTemplate->getProcessedTemplate($data);
                $receivers = Mage::getStoreConfig('contact_section/contact_group/contact_admin_email');

                $receiversData = explode(',', $receivers);
                $receiversEmail = array();
                foreach ($receiversData as $key => $emailId) {
                    $receiversEmail[] = $emailId;
                }

                $fromName  = Mage::helper('perficient_contact')->getFromDetails('name');
                $fromEmail = Mage::helper('perficient_contact')->getFromDetails('email');

                $mail = Mage::getModel('core/email')
                    ->setToName('Admin')
                    ->setToEmail($receiversEmail)
                    ->setBody($processedTemplate)
                    ->setSubject('Subject :New contact details from store.')
                    ->setFromEmail($fromEmail)
                    ->setFromName($fromName)
                    ->setType('html');
                try{
                    $mail->send();
                }
                catch(Exception $error)
                {
                    Mage::getSingleton('core/session')->addError($error->getMessage());
                    return false;
                }
                $messages = "Your Question successfully Submitted.";
                Mage::getSingleton('core/session')->addSuccess($messages);
            }
            catch (Exception $e) {
                $messages = $e->getMessage();
                Mage::getSingleton('core/session')->addError($messages);
            }
        }
        $this->_redirectReferer();
    }
}

