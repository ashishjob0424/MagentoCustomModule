<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 3/25/2016
 * Time: 2:51 PM
 */

/**
 * Class Perficient_Contact_Adminhtml_ContactController
 */
class Perficient_Contact_Adminhtml_ContactController extends Mage_Adminhtml_Controller_Action
{
    /**
     * Default action to load default layout
     */
    public function indexAction()
    {
        $this->loadLayout()->_setActiveMenu('contact');
        $this->renderLayout();
    }

    /**
     * Delete
     */
    public function massRemoveAction()
    {
        try {
            $ids = $this->getRequest()->getPost('contact_ids', array());
            foreach ($ids as $id) {
                $model = Mage::getModel("perficient_contact/contact");
                $model->setId($id)->delete();
            }
            Mage::getSingleton("adminhtml/session")->addSuccess(
                Mage::helper("adminhtml")->__("Item(s) was successfully removed")
            );
        }
        catch (Exception $e) {
            Mage::getSingleton("adminhtml/session")->addError($e->getMessage());
        }
        $this->_redirect('*/*/');
    }

    /**
     * Export contact grid to CSV format
     */
    public function exportCsvAction()
    {
        $fileName   = 'contact.csv';
        $grid       = $this->getLayout()->createBlock('perficient_contact/adminhtml_contact_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getCsvFile());
    }
    /**
     *  Export contact grid to Excel XML format
     */
    public function exportExcelAction()
    {
        $fileName   = 'contact.xml';
        $grid       = $this->getLayout()->createBlock('perficient_contact/adminhtml_contact_grid');
        $this->_prepareDownloadResponse($fileName, $grid->getExcelFile($fileName));
    }
}