<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 14-04-2016
 * Time: 16:03
 */
class Perficient_Contact_Model_Observer
{
    public function updatemenu(Varien_Event_Observer $observer)
    {
        // if module is active
        if (!Mage::getStoreConfig('advanced/modules_disable_output/Perficient_Contact')) {
            $layout = Mage::getSingleton('core/layout');

            // remove all the blocks you don't want
            $layout->getUpdate()->addUpdate('<remove name="catalog.topnav"/>');

            // load layout updates by specified handles
            $layout->getUpdate()->load();

            // generate xml from collected text updates
            $layout->generateXml();

            // generate blocks from xml layout
            $layout->generateBlocks();

        }
    }
}