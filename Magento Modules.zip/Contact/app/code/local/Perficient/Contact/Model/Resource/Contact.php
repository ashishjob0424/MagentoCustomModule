<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 18-04-2016
 * Time: 17:04
 */
class Perficient_Contact_Model_Resource_Contact extends Mage_Core_Model_Resource_Db_Abstract
{
    public function _construct()
    {
         $this->_init('perficient_contact/contact', 'contact_id');
    }
}
