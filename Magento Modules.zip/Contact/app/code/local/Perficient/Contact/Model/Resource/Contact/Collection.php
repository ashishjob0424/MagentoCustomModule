<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 18-04-2016
 * Time: 17:31
 */
class Perficient_Contact_Model_Resource_Contact_Collection extends Mage_Core_Model_Resource_Db_Collection_Abstract
{
    public function _construct()
    {
        parent::_construct();
        $this->_init('perficient_contact/contact');
    }
}
