<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 18-04-2016
 * Time: 17:02
 */
class Perficient_Contact_Model_Contact extends Mage_Core_Model_Abstract
{
    public function _construct()
    {
        $this->_init('perficient_contact/contact');
    }
}
