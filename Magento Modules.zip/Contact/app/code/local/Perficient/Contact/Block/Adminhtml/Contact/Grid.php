
<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 22-04-2016
 * Time: 11:56
 */
class Perficient_Contact_Block_Adminhtml_Contact_Grid extends Mage_Adminhtml_Block_Widget_Grid
{
    /**\
     * Perficient_Contact_Block_Adminhtml_Contact_Grid constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->setId("contactGrid");
        $this->setDefaultSort("contact_id");
        $this->setDefaultDir("DESC");
        $this->setSaveParametersInSession(true);
    }

    /**
     * @return Mage_Adminhtml_Block_Widget_Grid
     */
    protected function _prepareCollection()
    {
        $collection = Mage::getModel("perficient_contact/contact")->getCollection();
        $this->setCollection($collection);
        return parent::_prepareCollection();
    }

    /**
     * @return $this
     * @throws Exception
     * Grid Column
     */
    protected function _prepareColumns()
    {
        $this->addColumn(
            "faq_id", array(
                "header" => Mage::helper("perficient_contact")->__("ID"),
                "align" =>"right",
                "width" => "50px",
                "type" => "number",
                "index" => "contact_id",
            )
        );

        $this->addColumn(
            "first_name", array(
                "header" => Mage::helper("perficient_contact")->__("Name"),
                "index" => "first_name",
                'renderer'  => 'Perficient_Contact_Block_Adminhtml_Renderer_CustomerName',
            )
        );

        $this->addColumn(
            "email", array(
                "header" => Mage::helper("perficient_contact")->__("Email"),
                "index" => "email",
            )
        );

        $this->addColumn(
            "company_name", array(
                "header" => Mage::helper("perficient_contact")->__("Company Name"),
                "index" => "company_name",
            )
        );

        $this->addColumn(
            "address", array(
                "header" => Mage::helper("perficient_contact")->__("Address"),
                "index" => "address_one",
                'renderer'  => 'Perficient_Contact_Block_Adminhtml_Renderer_Address',
            )
        );

        $this->addColumn(
            "telephone", array(
                "header" => Mage::helper("perficient_contact")->__("Telephone"),
                "index" => "telephone",
            )
        );

        $this->addColumn(
            "created_date", array(
                "header" => Mage::helper("perficient_contact")->__("Contact Date"),
                "align" =>"left",
                "width" => "250px",
                "type" => "datetime",
                "index" => "created_date",
            )
        );


        if (!Mage::app()->isSingleStoreMode()) {
            $this->addColumn(
                'store_id', array(
                    'header'    => Mage::helper('sales')->__('Store'),
                    'index'     => 'store_id',
                    'type'      => 'store',
                    'store_view'=> true,
                    'display_deleted' => true,
                )
            );
        }

        $this->addExportType('*/*/exportCsv', Mage::helper('sales')->__('CSV'));
        $this->addExportType('*/*/exportExcel', Mage::helper('sales')->__('Excel'));

        return parent::_prepareColumns();
    }

    /**
     * @return $this
     * For Mass Action
     */
    protected function _prepareMassaction()
    {
        $this->setMassactionIdField('contact_id');
        $this->getMassactionBlock()->setFormFieldName('contact_ids');
        $this->getMassactionBlock()->setUseSelectAll(true);
        $this->getMassactionBlock()->addItem(
            'remove_contact', array(
                'label'=> Mage::helper('perficient_contact')->__('Remove Contact'),
                'url'  => $this->getUrl('*/contact/massRemove'),
                'confirm' => Mage::helper('perficient_contact')->__('Are you sure?')
            )
        );
        return $this;
    }
}