<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 22-04-2016
 * Time: 12:29
 */
class Perficient_Contact_Block_Adminhtml_Renderer_Address
      extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
    /**
     * @param Varien_Object $row
     * @return string
     * Return combine customer address
     */
    public function render(Varien_Object $row)
    {
        if ($row->getData('address_one') != NULL || $row->getData('address_two') != NULL) {
            $addressOne = $row->getData('address_one');
            $addressTwo = $row->getData('address_two');
            $state      = $row->getData('state');
            $city       = $row->getData('city');
            $zip        = $row->getData('zip');
            $country    = $row->getData('country');
            return $addressOne . ' ' . $addressTwo . ' ' . $city . ' ' . $state . ' ' . $country . ' ' . $zip;
        } else {
            return Mage::helper('perficient_contact')->__('No Address Assigned');
        }
    }
}