<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 14-04-2016
 * Time: 18:56
 */
class Perficient_Contact_Block_Html_Topmenu extends Mage_Page_Block_Html_Topmenu
{
    /**
     * @param string $outermostClass
     * @param string $childrenWrapClass
     * @return string
     * Adds New Menu
     */
    public function getHtml($outermostClass = '', $childrenWrapClass = '')
    {
        //Confg Status Value
        $configValue = Mage::getStoreConfig('contact_section/contact_group/contact_fieldset_status');
        $html = parent::getHtml($outermostClass = '', $childrenWrapClass = '');
        if (Mage::helper('core/data')->isModuleEnabled('Perficient_Contact') && $configValue) {
            $html .= "<li class='level0'>
                           <a href='" . Mage::getUrl('perficient_contact') . "'>
                               <span>" . Mage::helper('perficient_contact')->__('Contact Us') . "</span>
                           </a>
                       </li>";
        }
        return $html;
    }
}