<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 22-04-2016
 * Time: 11:55
 */
class Perficient_Contact_Block_Adminhtml_Contact extends Mage_Adminhtml_Block_Widget_Grid_Container
{
    /**
     * Perficient_Contact_Block_Adminhtml_Contact constructor.
     */
    public function __construct()
    {
        parent::__construct();
        $this->_controller = "adminhtml_contact";
        $this->_blockGroup = "perficient_contact";
        $this->_headerText = Mage::helper("perficient_contact")->__("Contact Manager");
        $this->_removeButton('add');
    }
}