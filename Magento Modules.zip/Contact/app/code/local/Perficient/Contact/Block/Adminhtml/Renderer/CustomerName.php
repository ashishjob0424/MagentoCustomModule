<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 22-04-2016
 * Time: 12:29
 */
class Perficient_Contact_Block_Adminhtml_Renderer_CustomerName
      extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
    /**
     * @param Varien_Object $row
     * @return mixed|string
     * Returns Customer name
     */
    public function render(Varien_Object $row)
    {
        if ($row->getData('first_name') != NULL || $row->getData('last_name') != NULL) {
            $firstName = $row->getData('first_name');
            $lastName = $row->getData('last_name');
            if ($lastName != NULL) {
                return $firstName . ' ' . $lastName;
            } else {
                return $firstName;
            }
        } else {
            return Mage::helper('perficient_contact')->__('No Name Assigned');
        }
    }
}