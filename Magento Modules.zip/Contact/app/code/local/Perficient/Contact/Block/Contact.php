<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 15-04-2016
 * Time: 17:14
 */
class Perficient_Contact_Block_Contact extends Mage_Core_Block_Template
{
    /**
     * @return string
     * Form action
     */
    public function getActionOfForm()
    {
        return $this->getUrl('contact/index/save');
    }

    /**
     * @return mixed
     * return country collection
     */
    public function getCountryList()
    {
        $_countries = Mage::getResourceModel('directory/country_collection')
            ->loadData()
            ->toOptionArray(false);
        return $_countries;
    }

    /**
     * @return mixed
     * Return default store country
     */
    public function getDefaultStoreCountry()
    {
        $countryCode = Mage::getStoreConfig('general/country/default');
        return $countryCode;
    }

    /**
     * @return mixed
     * return default state collection
     */
    public function getDefaultStateList()
    {
        $countryCode = Mage::getStoreConfig('general/country/default');
        $regionCollection = Mage::getModel('directory/region_api')->items($countryCode);
        return $regionCollection;
    }
}