<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 14-04-2016
 * Time: 16:34
 */
class Perficient_Contact_Helper_Data extends Mage_Core_Helper_Abstract
{
    /**
     * @param $type
     * @return mixed
     * Returns Name and Email
     */
    public function getFromDetails($type)
    {
        $senderType = Mage::getStoreConfig('contact_section/contact_group/custom_identity');
        if ($type == 'name') {
            $name = $this->getSenderInfo($type, $senderType);
            return $name;
        } elseif ($type == 'email') {
            $email = $this->getSenderInfo($type, $senderType);
            return $email;
        }
    }

    /**
     * @param $type
     * @param $senderType
     * @return mixed
     * Returns Name and Email Sender Type wise
     */
    public function getSenderInfo($type,$senderType)
    {
        if ($senderType == 'general') {
            if ($type == 'name') {
                return Mage::getStoreConfig('trans_email/ident_general/name');
            } elseif ($type == 'email') {
                return Mage::getStoreConfig('trans_email/ident_general/email');
            }
        } elseif ($senderType == 'sales') {
            if ($type == 'name') {
                return Mage::getStoreConfig('trans_email/ident_sales/name');
            } elseif ($type == 'email') {
                return Mage::getStoreConfig('trans_email/ident_sales/email');
            }
        } elseif ($senderType == 'support') {
            if ($type == 'name') {
                return Mage::getStoreConfig('trans_email/ident_support/name');
            } elseif ($type == 'email') {
                return Mage::getStoreConfig('trans_email/ident_support/email');
            }
        } elseif ($senderType == 'custom1') {
            if ($type == 'name') {
                return Mage::getStoreConfig('trans_email/ident_custom1/name');
            } elseif ($type == 'email') {
                return Mage::getStoreConfig('trans_email/ident_custom1/email');
            }
        } elseif ($senderType == 'custom2') {
            if ($type == 'name') {
                return Mage::getStoreConfig('trans_email/ident_custom2/name');
            } elseif ($type == 'email') {
                return Mage::getStoreConfig('trans_email/ident_custom2/email');
            }
        }

    }
}