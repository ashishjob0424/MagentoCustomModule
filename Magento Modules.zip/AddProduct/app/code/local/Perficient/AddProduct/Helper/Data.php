<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 12-04-2016
 * Time: 11:55
 */
class Perficient_AddProduct_Helper_Data extends Mage_Core_Helper_Abstract
{
    public function checkForFreeProduct($productId)
    {
        $freeProductSettingId = Mage::getStoreConfig('addproduct_section/addproduct_group/addproduct_product_id');
        if ($freeProductSettingId == $productId) {
            $configValue = Mage::getStoreConfig('addproduct_section/addproduct_group/addproduct_field_val');
            if ($configValue) {
                return true;
            }

        }
    }
}