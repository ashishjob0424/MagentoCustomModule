<?php

/**
 * Created by PhpStorm.
 * User: ashish.madankar
 * Date: 12-04-2016
 * Time: 12:06
 */
class Perficient_AddProduct_Model_Observer
{
    public function updatestatus(Varien_Event_Observer $observer)
    {
        $this->updatecart();
    }
    public function updatecart(Varien_Event_Observer $observer)
    {
        //Confg Status Value
        $configValue = Mage::getStoreConfig('addproduct_section/addproduct_group/addproduct_field_val');
        //Minimum cart value to add free product
        $cartValue = Mage::getStoreConfig('addproduct_section/addproduct_group/addproduct_cart_val');
        //Product Id of free product
        $productId = Mage::getStoreConfig('addproduct_section/addproduct_group/addproduct_product_id');
        if ($configValue) {
            $totals = Mage::getSingleton('checkout/session')->getQuote()->getTotals(); //Total object
            $subtotal = $totals["subtotal"]->getValue(); //Subtotal value
            $grandtotal = $totals["grand_total"]->getValue(); //Grandtotal value
            if ($grandtotal >= $cartValue) {
                $quote = Mage::getSingleton('checkout/session')->getQuote();
                $items = $quote->getAllVisibleItems();
                $isProductInCart = 0;
                foreach ($items as $_item) {
                    if ($_item->getProductId() == $productId) {
                        $isProductInCart = 1;
                        break;
                    }
                }
                if ($isProductInCart == 0) {
                    // Set Product Quantity
                    $qty = '1';
                    $_product = Mage::getModel('catalog/product')->load($productId);
                    $cart = Mage::getModel('checkout/cart');
                    $cart->init();
                    $cart->addProduct($_product, array('qty' => $qty));
                    // Save Product to cart
                    $cart->save();
                    Mage::getSingleton('checkout/session')->setCartWasUpdated(true);
                }
            } else {
                $quote = Mage::getSingleton('checkout/session')->getQuote();
                $items = $quote->getAllVisibleItems();
                $isProductInCart = 0;
                foreach ($items as $_item) {
                    if ($_item->getProductId() == $productId) {
                        $isProductInCart = 1;
                        break;
                    }
                }
                if ($isProductInCart == 1) {
                    $cartHelper = Mage::helper('checkout/cart');
                    $items = $cartHelper->getCart()->getItems();
                    foreach ($items as $item) {
                        $itemId = $item->getItemId();
                        $cartProdId = $item->getProduct()->getId();
                        if ($cartProdId == $productId) {
                            $cartHelper->getCart()->removeItem($itemId)->save();
                        }
                    }
                }
            }
        } else {
            $quote = Mage::getSingleton('checkout/session')->getQuote();
            $items = $quote->getAllVisibleItems();
            $isProductInCart = 0;
            foreach ($items as $_item) {
                if ($_item->getProductId() == $productId) {
                    $isProductInCart = 1;
                    break;
                }
            }
            if ($isProductInCart == 1) {
                $cartHelper = Mage::helper('checkout/cart');
                $items = $cartHelper->getCart()->getItems();
                foreach ($items as $item) {
                    $itemId = $item->getItemId();
                    $cartProdId = $item->getProduct()->getId();
                    if ($cartProdId == $productId) {
                        $cartHelper->getCart()->removeItem($itemId)->save();
                    }
                }
            }
        }
    }
}